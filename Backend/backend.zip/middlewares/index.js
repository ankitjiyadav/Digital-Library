const adminMiddlerware=require('./adminMiddlerware');
const authValidation=require('./authValidation');
const seller=require('./sellerMiddlerware');

module.exports={
    adminMiddlerware,
    authValidation,
    seller
}