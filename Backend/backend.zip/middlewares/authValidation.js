const express=require('express');
const jwt=require('jsonwebtoken');
const {key}=require('../util/secret');
  

// console.log(key.secret_key)
const generate_token=(id,role)=>{

     console.log("jwt function",id,role);

     const token=jwt.sign(
        {id,role},
        key.secret_key,
        {expiresIn:'1h'}
     );

     return token
}


const verify_token=async(req,res,next)=>{
    try{
           const{new_token}=req.body;
            const result=await jwt.verify(new_token,key.secret_key);
            if(result){
                next();
            }else{
                return res.send({status:404,message:"token expire"});
            }

    }catch(err){
        return res.send({status:500,message:err.message});
    }
}





module.exports={
    generate_token,
    verify_token
}