const adminController=require('./registrationController');
// const cofig=require('../config/dbConnection');
const sellerController=require('./sellerController');


module.exports={
    adminController,
    sellerController,
}