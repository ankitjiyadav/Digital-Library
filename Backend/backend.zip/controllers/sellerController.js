const express = require('express');
const sellerModel = require('../models/sellerModel');
const { findOne } = require('../models/registrationModel');



const seller_detail_add = async (req, res) => {
    try {
        const { name, lastName, pincode, address, city, totalSite, mobile, status } = req.body;

        const exData = await sellerModel.findOne({ mobile });
        if (exData) {
            return res.send({ status: 500, message: "User already exists" });
        }
        const result = await sellerModel.create({
            name, lastName, pincode, address, city, totalSite, mobile, status
        })
        if (result) {
            return res.send({ status: 200, message: "successfully" });
        } else {
            return res.send({ status: 500, message: "internal server errror" });
        }
    } catch (err) {
        return res.send({ status: 500, message: err.message });
    }
}


const sellerAllDetail = async (req, res) => {
    try {
        const result = await sellerModel.find({});
        return res.send({ status: 200, data: result });
    } catch (err) {
        return res.send({ status: 500, message: err.message });
    }
}


module.exports = {
    seller_detail_add,
    sellerAllDetail,
}