const express = require("express");
const router = express.Router();
const controller=require('../controllers/index')
const middlewares=require('../middlewares/index')
var bodyParser = require('body-parser')
const multer = require('multer');
const fs=require('fs')

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        let uploadPath = "./uploads/general"; // Default folder

        // Checking field name to determine folder
        if (file.fieldname === "image") {
            uploadPath = "./uploads/images";
        } else if (file.fieldname === "aadhar") {
            uploadPath = "./uploads/aadhar";
        }

        // Ensure the directory exists
        fs.mkdirSync(uploadPath, { recursive: true });

        cb(null, uploadPath);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + "-" + file.originalname);
    },
});

// Multer Instance for Multiple Files
const upload = multer({ storage: storage });
router.use(express.json());
router.use(express.urlencoded({ extended: true }));


//*****************   start Registration,login   **************//

router.post( "/registration", upload.fields([{ name: "image", maxCount: 1 },{ name: "aadhar", maxCount: 1 }]),
    middlewares.adminMiddlerware.adminValidation,controller.adminController.adminRegistration
);
router.post("/login",controller.adminController.login);
router.post("/send/otp",controller.adminController.generateOtp);
router.post("/otp/verify",upload.none(),controller.adminController.otpVerify);

// ******************** End ******************  //


// ************** seller  start *****************//

router.post("/seller/detail/add",upload.none(),middlewares.seller.sellerValidation,controller.sellerController.seller_detail_add);
router.get("/seller/allDetail",controller.sellerController.sellerAllDetail);

module.exports = router;
