

const key={
            secret_key:"abcdef",
            userName:"ssvv_online",
            apikey:"97971-6CEAF",
}

module.exports={key};