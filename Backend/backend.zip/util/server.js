const server={
    rootServer:3000,
}

module.exports=server;